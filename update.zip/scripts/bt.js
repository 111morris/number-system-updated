
const choiceFrom = document.querySelector("#choiceFrom");
const choiceTo = document.querySelector("#choiceTo");
const inputValue = document.querySelector("#inputValue");
const convertBtn = document.querySelector("#convertBtn");
const resultArea = document.querySelector("#resultArea");
const errorMessage = document.querySelector('#errorMessage');


choiceFrom.addEventListener('change', checkValidation);

inputValue.addEventListener('input', checkValidation);

function checkValidation() {
 const choice = choiceFrom.value;
 const value = inputValue.value;
 let isValid = false;
 let theBase;
 switch (choice) {
  case '1':
   isValid = /^[0-9]+$/.test(value);
   theBase = 'decimal';
   break;
  case '2':
   isValid = /^[01]+$/.test(value);
   theBase = 'binary';
   break;
  case '3':
   isValid = /^[0-7]+$/.test(value);
   theBase = 'octal';
   break;
  case '4':
   isValid = /^[0-9A-Fa-f]+$/.test(value);
   theBase = 'hexadecimal';
   break;
 }

 if (!isValid && value !== '') {
  errorMessage.innerText = `Invalid ${theBase} value`;
  convertBtn.disabled = true;
 } else {
  errorMessage.innerText = '';
  convertBtn.disabled = true;
 }
}

convertBtn.addEventListener('click', () => {
 let result = '';
 // const from = choiceFrom.value;
 // const to = choiceTo.value;
 const value = inputValue.value;

 // Convert and display result
 // const result = convertBases(from, to, value);
 // resultArea.innerText = result;

 radix = fromTo();
 result = convertDecimal(value, radix);
 console.log(result);
});


function convertDecimal(value, base) {
 let conversion;
 // console.log(parseInt(value, base));
 conversion = parseInt(value, base);
 console.log(conversion);
 console.log('defgf')
}


// function convertBases(from, to, value) {
//  const decimalValue = toDecimal(value, radix);
//  return fromDecimal(to, decimalValue);
// }

function fromTo() {
 switch (choiceFrom.value) {
  case '1':
   switch (choiceTo.value) {
    case 'one':
     return '10'
    case 'two':
     return '2'
    case 'three':
     return '8'
    case 'four':
     return '16'
   }
  case '2':
  case '3':
  case '4':

   switch (choiceTo.value) {
    case 'one':
     return '10'
    case 'two':
     return '2'
    case 'three':
     return '8'
    case 'four':
     return '16'
   }
   break;
 }
}


function convertBinary(value, radix) {
 return parseInt(value, radix);
}

